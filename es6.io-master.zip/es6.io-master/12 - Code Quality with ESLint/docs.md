# Fake JavaScript Docs

```js
var x = 100;
```
